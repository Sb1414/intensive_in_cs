window.PRODUCT_VERSION = 'r__64.1.0-rc1_028c396d226__s21__STABLE' || undefined;
window.KEYCLOAK_ENDPOINT = 'https://auth.sberclass.ru/auth' || undefined;
window.SUPPORT_DOMAIN = 'support-s21.dmz.prod-ins2.pcbl.local' || undefined;
window.KEYCLOAK_CLIENT = 'school21' || undefined;
window.SENTRY_DSN = 'https://e4f3278a73844eb2bab49f2fd0d53c26@sentry.pcbltools.ru/4' || undefined;
window.GTM_ID = 'GTM-KQ8HBZ2' || undefined;
window.GITLAB_URL = 'https://repos.21-school.ru' || undefined;
window.VIDEO_URL = 'https://cdn.sberclass.ru/services/storage/download' || undefined;
